var sameTime = 20;
var linhas = [];
var socket = io({ transports: ['websocket'], upgrade: false });

function hide(id) {
    $(`#${id}`).toggle();
}

$("#form").on("submit", function () {
    event.preventDefault();
    finalizado = false;
    $('#reprovadas').html('');
    $('#aprovadas').html('');
	$('#verificacao').html('');
    $('#aprovadas_count').html('0');
    $('#reprovadas_count').html('0');
$('#verificacao_count').html('0');

    remover_linhas_vazias();

    linhas = $('#lista').val().replace(/\r/g, '').split("\n").filter(Boolean)

    console.log(linhas.length);

    $('#lista').val(null)
    $('input').attr('disabled', true);
    $('input').val('Carregando...');

    testar();
});

function testar() {
    socket.emit('chk', linhas.slice(0, sameTime));
    linhas.splice(0, sameTime);
}

function removerLinha() {
    var lines = $("#lista").val().split('\n');
    lines.splice(0, 1);
    $("#lista").val(lines.join("\n"));
}

var finalizado = false;
socket.on('resultado', function (data) {
    var meucu = data;
    if (meucu.status == 0) {
        $('#aprovadas_count').html(parseInt($('#aprovadas_count').html()) + 1);
        $('#aprovadas').append(meucu.msg + "<br>");
    } else if (meucu.status == 1) {
        $('#reprovadas_count').html(parseInt($('#reprovadas_count').html()) + 1);
        $('#reprovadas').append(meucu.msg + "<br>");
		} else if (meucu.status == 2) {
        $('#verificacao_count').html(parseInt($('#verificacao_count').html()) + 1);
        $('#verificacao').append(meucu.msg + "<br>");
    } else if (meucu.status == 3) {
        $('#proxydie_count').html(parseInt($('#proxydie_count').html()) + 1);
        $('#proxydie').append(meucu.msg + "<br>");
    } else {
        $('#error').append(meucu.msg + "<br>");
    }

    if (linhas && linhas[0] && data) {
        socket.emit('chk', linhas.slice(0, sameTime));
        linhas.splice(0, sameTime);
    }

    if (linhas && !linhas[0] && !finalizado) {
        finalizado = true;
        $('input').attr('disabled', false);
        $('input').val('Chegando Lixos by BlackCard');
    }

});

function unique(array) {
    return array.filter(function (el, index, arr) {
        return index == arr.indexOf(el);
    });
}

function remover_linhas_vazias() {
    var array = $("#lista").val().split('\n');
    array = unique(array);
    for (i = 0; i < array.length; i++) {
        array[i] = array[i].trim();
        array[i] = array[i].replace('   ', '');
        if (array[i].length === 0) {
            array.splice(i, 1);
        }
    }
    $("#lista").val(array.join("\n"));
}

$('#lista').keyup(() => {
    $('#lista').scrollTop(0);
});

hide(`reprovadas`)